from flask import Flask, render_template, request, redirect, url_for, flash
import os
import json
import bcrypt
import random

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Create users directory if it doesn't exist
if not os.path.exists('users'):
    os.makedirs('users')

# Helper to generate OTP
def generate_otp():
    return str(random.randint(100000, 999999))

@app.route('/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        captcha = request.form['captcha']
        password = request.form['password']
        
        # Dummy captcha check
        if captcha.strip().lower() != 'human':
            flash('Captcha validation failed! Type "human" to proceed.', 'error')
            return redirect(url_for('register'))
        
        # Hash password
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        
        # Generate OTP
        otp = generate_otp()

        # Save user
        user_data = {
            'name': name,
            'email': email,
            'password': hashed_password.decode('utf-8'),
            'otp': otp
        }
        
        with open(f'users/{email}.json', 'w') as f:
            json.dump(user_data, f)
        
        flash(f'Registration successful! Your OTP is: {otp}', 'success')
        return redirect(url_for('login'))
        
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        otp = request.form['otp']
        
        user_path = f'users/{email}.json'
        
        if not os.path.exists(user_path):
            flash('User not found!', 'error')
            return redirect(url_for('login'))
        
        with open(user_path, 'r') as f:
            user_data = json.load(f)
        
        if user_data['otp'] == otp:
            flash('Login successful!', 'success')
        else:
            flash('Invalid OTP!', 'error')
        
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)
